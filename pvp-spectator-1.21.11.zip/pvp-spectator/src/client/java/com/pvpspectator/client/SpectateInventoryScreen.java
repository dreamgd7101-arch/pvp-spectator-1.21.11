package com.pvpspectator.client;

import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;

/** Vista de solo lectura del inventario de otro jugador: se anula todo clic sobre slots. */
public class SpectateInventoryScreen extends InventoryScreen {
    public final PlayerEntity target;

    public SpectateInventoryScreen(PlayerEntity target) {
        super(target);
        this.target = target;
    }

    @Override
    protected void onMouseClick(Slot slot, int slotId, int button, SlotActionType actionType) { }
}
